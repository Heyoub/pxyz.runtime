//! Output Emission Module

pub mod binary;
pub mod audit;
pub mod text;
pub mod mermaid;
